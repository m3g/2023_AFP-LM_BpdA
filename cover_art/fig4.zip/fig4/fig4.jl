using DelimitedFiles, Plots, LaTeXStrings, Statistics, ColorSchemes

plot_font = "Computer Modern"

default(
           fontfamily=plot_font,
           framestyle=:box,
           label=nothing,
           grid=false,
	   dpi=300
       )

#scalefontsizes(); scalefontsizes(1.3)

plot(layout=(1))

sp=1

  file1 = readdlm("projection.dat")
  file2 = readdlm("q_f.dat")

  x = file1[:,1]
  y = file1[:,2]
  q = file2[:,1]

  ids  = sortperm(q);
  x1 = x[ids]; 
  y1 = y[ids];
  q1 = sort(q);

scatter!(border=:none,right_margin=7Plots.mm,colorbar_titlefontsize=8,subplot=sp)
scatter!(x1,y1,zcolor=q1,ms=1.2,markerstrokewidth=0.0,colorbar_title="\n Fraction of native contacts",subplot=sp)

plot!(size=(300*0.9,220*0.9))

savefig("scatter.pdf")